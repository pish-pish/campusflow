import React from 'react';
import UserDetails from './UserDetails';

const UserDetailsPage = (props) => (
    <div className="user-details">
        <UserDetails/>
    </div>
)

export default UserDetailsPage;